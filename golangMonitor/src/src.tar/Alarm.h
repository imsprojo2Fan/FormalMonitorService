/*
* Copyright(C) 2010,Hikvision Digital Technology Co., Ltd 
* 
* File   name��Alarm.h
* Discription��
* Version    ��1.0
* Author     ��panyd
* Create Date��2010_3_25
* Modification History��
*/

//Alarm Test
int Demo_Alarm();

//Alarm listening
int Demo_AlarmListen();

// ����
int Demo_AlarmFortify();

